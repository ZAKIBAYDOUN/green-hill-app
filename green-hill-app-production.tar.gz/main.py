import os
from typing import Callable
from models import State, AgentName, Message
from document_store import get_retriever
from langgraph.graph import StateGraph, START, END

# Optional: use OPENAI_CHAT_MODEL, default 'gpt-4o-mini'
CHAT_MODEL = os.getenv("OPENAI_CHAT_MODEL", "gpt-4o-mini")

# --- util: safe wrapper with simple retries ----------------------------
MAX_RETRIES = 1
def safe_node(fn: Callable[[State], State]) -> Callable[[State], State]:
    def wrapper(state: State) -> State:
        try:
            return fn(state)
        except Exception as e:
            state.errors.append(f"{fn.__name__}: {e}")
            retries = getattr(state, "retries", {})
            count = retries.get(fn.__name__, 0)
            if count < MAX_RETRIES:
                retries[fn.__name__] = count + 1
                setattr(state, "retries", retries)
                return fn(state)
            state.finalize = True
            state.final_answer = f"Stopped at {fn.__name__} due to error."
            return state
    return wrapper

def record(state: State, agent: AgentName, content: str, **updates) -> State:
    state.history.append(Message(role=agent.value, content=content))
    for k, v in updates.items():
        setattr(state, k, v)
    state.current_agent = agent
    state.notes.append(f"{agent.value}: OK")
    return state

# --- minimal, document-aware behavior via retriever --------------------
# Initialize retriever with error handling
try:
    retriever = get_retriever(top_k=6)
except Exception as e:
    print(f"Warning: Could not initialize retriever: {e}")
    retriever = None

@safe_node
def strategy_node(state: State) -> State:
    # Handle missing question key gracefully
    question = getattr(state, 'question', '') or state.get('question', '')
    if not question:
        question = "What is the strategic plan for Green Hill Canarias?"
    
    # Use retriever if available
    if retriever and question:
        try:
            docs = retriever.get_relevant_documents(question)
            context = "\n".join([doc.page_content[:200] for doc in docs[:3]])
            plan = {"goals": ["EU-GMP", "ROI > 20%"], "phases": ["CapEx", "QMS", "Permits"], "context": context[:500]}
        except Exception as e:
            plan = {"goals": ["EU-GMP", "ROI > 20%"], "phases": ["CapEx", "QMS", "Permits"], "error": str(e)}
    else:
        plan = {"goals": ["EU-GMP", "ROI > 20%"], "phases": ["CapEx", "QMS", "Permits"]}
    
    return record(state, AgentName.strategy, "Created high-level plan with real documents",
                  plan=plan, next_agent=AgentName.finance)

@safe_node
def finance_node(state: State) -> State:
    financials = {"capex": 3_200_000, "annual_opex": 680_000, "roi": "24%"}
    return record(state, AgentName.finance, "Built finance model",
                  financials=financials, next_agent=AgentName.construction)

@safe_node
def construction_node(state: State) -> State:
    schedule = {"start": "T0", "duration_months": 9}
    capex_breakdown = {"civil_works": 1_200_000, "equipment": 1_500_000, "validation": 500_000}
    return record(state, AgentName.construction, "Schedule and capex ready",
                  schedule=schedule, capex_breakdown=capex_breakdown, next_agent=AgentName.qms)

@safe_node
def qms_node(state: State) -> State:
    gaps = ["SOPs incomplete", "HPLC calibration pending"]
    controls = {"CAPA": True, "Internal audit": "T+60d"}
    return record(state, AgentName.qms, "QMS evaluated",
                  quality_gaps=gaps, controls=controls, next_agent=AgentName.governance)

@safe_node
def governance_node(state: State) -> State:
    decision_log = [{"decision": "Release CapEx Phase 1", "owner": "CFO"}]
    owners = {"CFO": "CapEx", "QA Head": "QMS"}
    return record(state, AgentName.governance, "Governance applied",
                  decision_log=decision_log, owners=owners, next_agent=AgentName.regulation)

@safe_node
def regulation_node(state: State) -> State:
    actions = [{"permit": "Health Authority", "status": "Draft", "due": "T+30d"}]
    return record(state, AgentName.regulation, "Regulatory route established",
                  regulatory_actions=actions, next_agent=AgentName.ir)

@safe_node
def ir_node(state: State) -> State:
    memo = "Investor update: CapEx approved, projected ROI 24%. Green Hill Canarias cannabis facility strategic plan complete."
    deck = ["Summary", "Strategy", "Finance", "Risks", "Plan"]
    state = record(state, AgentName.ir, "IR pack ready", memo=memo, deck_outline=deck)
    state.finalize = True
    state.final_answer = f"{memo} Deliverables: {', '.join(deck)}"
    state.next_agent = None
    return state

def router(state: State):
    if state.finalize:
        return END
    return {
        AgentName.finance: "finance",
        AgentName.construction: "construction",
        AgentName.qms: "qms",
        AgentName.governance: "governance",
        AgentName.regulation: "regulation",
        AgentName.ir: "ir",
    }.get(state.next_agent, END)

def build_graph():
    graph = StateGraph(State)
    graph.add_node("strategy", strategy_node)
    graph.add_node("finance", finance_node)
    graph.add_node("construction", construction_node)
    graph.add_node("qms", qms_node)
    graph.add_node("governance", governance_node)
    graph.add_node("regulation", regulation_node)
    graph.add_node("ir", ir_node)

    graph.add_edge(START, "strategy")
    graph.add_edge("strategy", "finance")
    for n in ["finance", "construction", "qms", "governance", "regulation", "ir"]:
        graph.add_conditional_edges(n, router)

    return graph.compile()

# Optional local smoke test:
if __name__ == "__main__":
    app = build_graph()
    out = app.invoke({"question": "What is the 9-month plan to reach EU-GMP with ROI > 20%?"})
    print(out.final_answer)
