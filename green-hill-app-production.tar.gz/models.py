from enum import Enum
from typing import Dict, List, Optional
from pydantic import BaseModel, Field

class AgentName(str, Enum):
    strategy = "Strategy"
    finance = "Finance"
    construction = "Construction"
    qms = "QMS"
    governance = "Governance"
    regulation = "Regulation"
    ir = "InvestorRelations"

class Message(BaseModel):
    role: str
    content: str

class State(BaseModel):
    # Input - Made optional with default for LangSmith compatibility
    question: str = Field(default="What is the strategic plan for Green Hill Canarias?", description="Business question or task.")
    # Context & traces
    context: Dict = Field(default_factory=dict)
    history: List[Message] = Field(default_factory=list)
    notes: List[str] = Field(default_factory=list)
    # Artifacts
    plan: Optional[Dict] = None
    financials: Optional[Dict] = None
    schedule: Optional[Dict] = None
    capex_breakdown: Optional[Dict] = None
    quality_gaps: Optional[List[str]] = None
    controls: Optional[Dict] = None
    decision_log: Optional[List[Dict]] = None
    owners: Optional[Dict] = None
    regulatory_actions: Optional[List[Dict]] = None
    memo: Optional[str] = None
    deck_outline: Optional[List[str]] = None
    # Flow control
    current_agent: Optional[AgentName] = None
    next_agent: Optional[AgentName] = None
    finalize: bool = False
    # Result & errors
    decisions: List[Dict] = Field(default_factory=list)
    final_answer: Optional[str] = None
    errors: List[str] = Field(default_factory=list)
